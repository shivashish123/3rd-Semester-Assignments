#include<bits/stdc++.h>
using namespace std;
struct node{    //structure for the disjoint sets
int x;          //denoting the value in node
int r;          //denoting the rank of node
node *par;      //pointer to the parent
};
struct node* rep(struct node *v)    //returns the representative node of the set containing the element
{
    while(v!=v->par)
    {
        v=v->par;    //if it is not the root then go to its parent else return root
    }
    return v;
}
void findset(struct node** a,int v1,int v2,int n) //checks if v1 and v2 are in same set or not
{
    if(v1>n || v2>n || v1<1 || v2<1) //if v1 and v2 is not valid then print -1
    {
        cout<<-1<<endl;
        return ;
    }
    node *p1=rep(a[v1]);
    node *p2=rep(a[v2]);
    if(p1!=p2)  // if v1 and v2 belong to different set print 0 else 1
        cout<<0<<endl;
    else
        cout<<1<<endl;
}
void unionset(struct node** a,int v1,int v2,int n) //performs union by rank of node containing v1 and v2
{
    if(v1>n || v2>n || v1<1 || v2<1) // if v1 or v2 is not valid element then return
    {
        return ;
    }
    node *p1=rep(a[v1]);
    node *p2=rep(a[v2]);
    if(p1->r > p2->r) //if rank of representative of v1 is greater then representative of v1 becomes parent of representative of v2
    {
        p2->par=p1;
    }
    else if(p1->r < p2->r)//if rank of representative of v2 is greater then representative of v2 becomes parent of representative of v1
    {
        p1->par=p2;
    }
    else      //representative of v1 becomes parent of representative of v2 and rank of representative of v1 is incremented by 1
    {
        p2->par=p1;
        p1->r=p1->r+1;
    }

}
int main()
{
    node** a=NULL;  //array of pointers for storing the address of singleton sets
    int n=-1;       //denotes the number of singleton sets to create with operation 'N'
    int digit;      //used for taking input
    int fl=-1;     //denotes option like 'N','?','S'..
    int data=0;
    int i;
    int sp=0;       //denotes the number of spaces
    int v1=-1,v2=-1;
    while((digit=fgetc(stdin))!=EOF){
        int y=digit-48;
        if(digit=='N')
        {
            fl=0;
            for(i=0;i<=n;i++)
                {
                    delete a[i];  //deletes disjoint forests if exists
                }
            if(a!=NULL)
              delete a;
        }
        else if(digit=='\n' && fl==0)
        {
            n=data;         //number of singleton sets to create
            a=new node* [n+1]; //allocates space for array of pointers
            for(i=1;i<=n;i++)
            {
                a[i]=new node;
                a[i]->x=i;
                a[i]->r=1;
                a[i]->par=a[i];
            }
            data=0;
            fl=-1;
        }
        else if(digit=='?')
        {
            fl=1;
        }
        else if(digit==' ' && fl==1)
        {
            if(sp==0)
                sp=1;
            else if(sp==1)
            {
                v1=data;
            }
            data=0;
        }
        else if(digit=='\n' && fl==1)
        {
                v2=data;
                findset(a,v1,v2,n);  //checks if v1 and v2 are in same set or not
                data=0;
                sp=0;
                fl=-1;
        }
        else if(digit=='S')
        {
            fl=2;
        }
        else if(digit=='\n' && fl==2)
        {
            if(data>n || data<1)  //if input is not valid element
            {
                cout<<-1<<endl;
            }
            else
            {
                node *p1=rep(a[data]);  //prints the representative of set containing 'data'
                cout<<p1->x<<endl;
            }
            data=0;
            fl=-1;
        }
        else if(digit=='U')
        {
            fl=3;
        }
        else if(digit==' ' && fl==3)
        {
            if(sp==0)
                sp=1;
            if(sp==1)
                v1=data;
            data=0;
        }
        else if(digit=='\n' && fl==3)
        {
            v2=data;
            unionset(a,v1,v2,n);//performs union by rank of node containing v1 and v2
            fl=-1;
            sp=0;
            data=0;
        }
        else if(digit=='R')
        {
            fl=4;
        }
        else if(digit=='\n' && fl==4)
        {
            if(data>n || data<1)  //if input is not valid element
            {
                cout<<-1<<endl;
            }
            else
            {
                cout<<a[data]->r<<endl; //prints the rank of node containing 'data'
            }
            data=0;
            fl=-1;
        }
        else if(digit>='0' && digit<='9')
        {
            data=data*10+y;
        }
    }
    for(i=1;i<=n;i++)
        {
          delete a[i];      //deletes disjoint forests having nodes if exists
        }
    delete a;
    return 0;
}
